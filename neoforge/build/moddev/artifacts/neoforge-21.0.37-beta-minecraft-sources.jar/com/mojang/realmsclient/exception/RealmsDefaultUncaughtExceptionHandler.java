package com.mojang.realmsclient.exception;

import java.lang.Thread.UncaughtExceptionHandler;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class RealmsDefaultUncaughtExceptionHandler implements UncaughtExceptionHandler {
    private final Logger logger;

    public RealmsDefaultUncaughtExceptionHandler(Logger pLogger) {
        this.logger = pLogger;
    }

    @Override
    public void uncaughtException(Thread pThread, Throwable pThrowable) {
        this.logger.error("Caught previously unhandled exception", pThrowable);
    }
}
